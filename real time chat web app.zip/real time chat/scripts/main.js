const socket = io("http://localhost:8000");

const form = document.getElementById("send");
const messageinput = document.getElementById("messageInp");
const messagecontainer = document.querySelector(".container");
var audio = new Audio('notification_o14egLP.mp3'); 

const append = (message, position) => {
  const messagelement = document.createElement("div");
  messagelement.innerHTML = message;
  messagelement.classList.add("message");
  messagelement.classList.add(position);
  messagecontainer.appendChild(messagelement);
  if (position == 'left') { 
    audio.play();
  }
};

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const message = messageinput.value;
  append(`You: ${message}`, 'right');
  socket.emit('send', message);
  messageinput.value = "";
});

const name = prompt("Enter your name");

socket.emit("new-user-joined", name);

socket.on("user-joined", (name) => {
  append(`${name} joined the chat`, "right");
});

socket.on("receive", data => {
  append(`${data.name}: ${data.message}`, "left");
  // Check if the message contains an image URL
  const messageContent = `${data.name}: ${data.message}`;
  const imageRegex = /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png)/g;
  const isImage = imageRegex.test(messageContent);
  if (isImage) {
    append(`<img src="${messageContent}" class="message-img">`, "left");
  }
});

socket.on("left", name => {
  append(`${name} left the chat`, "left");
});
